const path = require('path');
const express = require('express');
const app = express();

const hostname = '192.168.1.6';
const port = 1324;

app.use(express.static(__dirname + '/public'));

app.get('/', function(req, res) {
    res.sendFile(path.join(__dirname + '/main.html'));
    // res.render("ThankYou.html");
});

app.listen(port, hostname, () => {
  console.log(`Server running at http://${hostname}:${port}/`);
});