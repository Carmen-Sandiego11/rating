
document.getElementById("demo").innerHTML = `You selected ${localStorage.getItem("rate")} out of 5`